import React from 'react';
import './App.css'; // Import the CSS file

const Background = () => (
  <section className="background">
    <h2 className="background-heading">Background</h2>
    <ul className="background-list">
      <li>ICS from KIPS College Gujranwala</li>
      <li>BSCS from GIFT UNIVERSITY GUJRANWALA</li>
      
    </ul>
  </section>
);

export default Background;
