import React from 'react';
import './App.css'; 

const Experience = () => (
  <section className="experience">
    <h2 className="experience-heading">Experience</h2>
    <ul className="experience-list">
    <li>Freelance Online Platform/Web</li>
    <li>Rhombix Technologies(Internship)</li>
    <li>Fiverr</li>
    <li>Upwork</li>
    <li>GlassDoor</li>    
    </ul>
  </section>
);
export default Experience;

